MonoType Display Serif (3 Styles: Regular, Italic, Display Bold) by Agnel Foundry
High-contrast editorial serif typeface crafted for architectural journals and modern luxury commerce.