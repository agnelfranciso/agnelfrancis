Nebula 3D Icons (48 Items) by Agnel Francis & Forma Lab
Monochrome, frosted glass and metallic procedural 3D icons optimized for contemporary web interfaces.